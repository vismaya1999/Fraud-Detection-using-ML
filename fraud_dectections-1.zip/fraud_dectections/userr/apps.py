from django.apps import AppConfig


class UserrConfig(AppConfig):
    name = 'userr'
